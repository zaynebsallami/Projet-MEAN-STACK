const mongoose = require('mongoose');
const Subcategory = require('./subcategory');  // Import Subcategory model

const CategorySchema = new mongoose.Schema({
  name: String,
  image: String,
  subcategories: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Subcategory' }],  // Reference to Subcategory model
});

const Category = mongoose.model('Category', CategorySchema);

module.exports = Category;
