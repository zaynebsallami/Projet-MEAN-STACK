const mongoose = require('mongoose');

const SubcategorySchema = new mongoose.Schema({
  name: String,
  description: String,
});

const Subcategory = mongoose.model('Subcategory', SubcategorySchema);

module.exports = Subcategory;
