import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-profile-client',
  standalone: true,
  imports: [FormsModule, CommonModule],
   encapsulation: ViewEncapsulation.None,
  templateUrl: './profile-client.component.html',
  styleUrls: ['./profile-client.component.scss']
})
export class ProfileClientComponent implements OnInit {
  user: any;
  emailChange = '';
  currentPassword = '';
  newPassword = '';
  darkMode = false;   
  newsletter = false;

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const token = localStorage.getItem('authToken');
    if (!token) {
      alert('No token found. Please log in.');
      this.logout();
      return;
    }
    this.getUser();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) {
      return new HttpHeaders();
    }
    return new HttpHeaders({ Authorization: `Bearer ${token}` });
  }

  getUser(): void {
    this.http.get<any>('http://localhost:3000/api/users/me', {
      headers: this.getAuthHeaders()
    }).subscribe({
      next: (response) => {
        if (response.success) {
          this.user = {
            _id: response.user._id,
            nom: response.user.nom || 'Not provided',
            email: response.user.email,
            telephone: response.user.telephone || 'Not provided',
            adresse: response.user.adresse || 'Not provided',
            dateNaissance: response.user.dateNaissance || 'Not provided',
            nombreCommandes: response.user.totalOrders || 0
          };
        }
      },
      error: (err) => {
        console.error('Error loading profile:', err);
      }
    });
  }

  updateEmail(): void {
    if (!this.emailChange || this.emailChange === this.user.email) {
      alert('Please enter a new email.');
      return;
    }
    this.http.put(`http://localhost:3000/api/users/${this.user._id}`, 
      { email: this.emailChange },
      { headers: this.getAuthHeaders() }
    ).subscribe({
      next: () => {
        alert('Email updated!');
        this.user.email = this.emailChange;
      },
      error: (err) => {
        alert('Could not update email.');
      }
    });
  }

  changePassword(): void {
    if (!this.currentPassword || !this.newPassword) {
      alert('Please fill both current and new password.');
      return;
    }
    this.http.post(`http://localhost:3000/api/users/${this.user._id}/change-password`,
      {
        currentPassword: this.currentPassword,
        newPassword: this.newPassword
      },
      { headers: this.getAuthHeaders() }
    ).subscribe({
      next: () => {
        alert('Password updated successfully.');
        this.currentPassword = '';
        this.newPassword = '';
      },
      error: (err) => {
        alert('Incorrect current password or server error.');
      }
    });
  }

  goToCart(): void {
    this.router.navigate(['/panier']);
  }

  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login-se']);
  }
}
